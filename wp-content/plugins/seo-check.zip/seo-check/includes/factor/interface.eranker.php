<?php

interface FactorDisplay 
{

    public static function getDisplay($endModel, $data, $report, $factor);

}

