<?php
/*
Template Name: Only Reviews
*/

global $THEMEREX_only_reviews;
$THEMEREX_only_reviews = true;

get_template_part('blog');
?>