<?php
// Don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>
<style type="text/css">
	div.tribe_settings {
		width: 90%;
	}
</style>
<div class="tribe_settings wrap">
	<?php screen_icon(); ?><h2><?php _e( 'Events Import (CSV)', 'tribe-events-calendar' ) ?></h2>

	<div class="form">
